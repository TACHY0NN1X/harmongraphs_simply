package com.harmonographs.simply;

import android.graphics.*;

public class ImageGen
   {

      public void generate(Bitmap bm,
                           int width, int height,
                           double f1, double f2,
                           double f3, double f4,
                           double d1, double d2,
                           double d3, double d4,
                           double p1, double p2,
                           double p3, double p4
                           )
         {

         double amp = height / 5.0;
         double iterations = 100 * (width + height);

         double t = 0.0;
         double dt = Math.PI / (width + height);

         p1 = Math.PI * p1;
         p2 = Math.PI * p2;
         p3 = Math.PI * p3;
         p4 = Math.PI * p4;

         int x, y;
         double m, n;
         int r, g, b;

         bm.eraseColor(Color.BLACK);

         for (int i = 0; i < iterations; i++)
            {

            m = amp * (Math.sin(f1 * t + p1)) * Math.exp(-d1 * t) +
               amp * (Math.sin(f2 * t + p2)) * Math.exp(-d2 * t) ;

            n = amp * (Math.sin(f3 * t + p3)) * Math.exp(-d3 * t) +
               amp * (Math.sin(f4 * t + p4)) * Math.exp(-d4 * t) ;

            x = ( int ) m + (width / 2);
            y = ( int ) n + (height / 2);

            if (x > 1 && y > 1 && y < height - 1 && x < width - 1)
               {

               int val = ( int )(1 + i * 254 / iterations);
               r = 128 - (val / 2);
               g = 255 - (val / 2);
               b = 128 + (val / 2);

               bm.setPixel((x - 1), (y + 1), Color.argb(255, r, g, b));
               bm.setPixel((x - 1), (y + 0), Color.argb(255, r, g, b)); 
               bm.setPixel((x - 1), (y - 1), Color.argb(255, r, g, b)); 
               bm.setPixel((x + 0), (y + 1), Color.argb(255, r, g, b)); 
               bm.setPixel((x + 0), (y + 0), Color.argb(255, r, g, b)); 
               bm.setPixel((x + 0), (y - 1), Color.argb(255, r, g, b)); 
               bm.setPixel((x + 1), (y + 1), Color.argb(255, r, g, b)); 
               bm.setPixel((x + 1), (y + 0), Color.argb(255, r, g, b)); 
               bm.setPixel((x + 1), (y - 1), Color.argb(255, r, g, b)); 
               }

            t += dt;

            }

         }
   }
