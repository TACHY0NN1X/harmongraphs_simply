package com.harmonographs.simply;

import android.app.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity 
   {
      int 
      width, 
      height;

      double 
      f1, f2,
      f3, f4,
      p1, p2,
      p3, p4,
      d1, d2, 
      d3, d4;

      EditText
      widthv, heightv,
      f1v, f2v,
      f3v, f4v,
      p1v, p2v,
      p3v, p4v,
      d1v, d2v,
      d3v, d4v;

      TableRow
      row1, row2, row3,
      row4, row5, row6,
      row7;

      Button
      generate, 
      cancel, 
      save;

      ImageView
      info,
      iv;

      ImageGen generator = new ImageGen();

      Bitmap bm;

      @Override
      protected void onCreate(Bundle savedInstanceState)
         {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.main);

         info = findViewById(R.id.info);
         widthv = findViewById(R.id.width);
         heightv = findViewById(R.id.height);
         f1v = findViewById(R.id.f1);
         f2v = findViewById(R.id.f2);
         f3v = findViewById(R.id.f3);
         f4v = findViewById(R.id.f4);

         p1v = findViewById(R.id.p1);
         p2v = findViewById(R.id.p2);
         p3v = findViewById(R.id.p3);
         p4v = findViewById(R.id.p4);

         d1v = findViewById(R.id.d1);
         d2v = findViewById(R.id.d2);
         d3v = findViewById(R.id.d3);
         d4v = findViewById(R.id.d4);

         row1 = findViewById(R.id.row1);
         row2 = findViewById(R.id.row2);
         row3 = findViewById(R.id.row3);
         row4 = findViewById(R.id.row4);
         row5 = findViewById(R.id.row5);
         row6 = findViewById(R.id.row6);
         row7 = findViewById(R.id.row7);

         generate = findViewById(R.id.generate);
         cancel = findViewById(R.id.cancel);
         save = findViewById(R.id.save);     
         iv = findViewById(R.id.iv);

         cancel.setVisibility(View.GONE);
         save.setVisibility(View.GONE);
         iv.setVisibility(View.GONE);

         generate.setOnClickListener(new View.OnClickListener(){
                  @Override
                  public void onClick(View v)
                     {

                     if ((f1v.getText().toString().length() == 0) ||
                         (f2v.getText().toString().length() == 0) ||
                         (f3v.getText().toString().length() == 0) ||
                         (f4v.getText().toString().length() == 0) ||

                         (p1v.getText().toString().length() == 0) ||
                         (p2v.getText().toString().length() == 0) ||
                         (p3v.getText().toString().length() == 0) ||
                         (p4v.getText().toString().length() == 0) ||

                         (d1v.getText().toString().length() == 0) ||
                         (d2v.getText().toString().length() == 0) ||
                         (d3v.getText().toString().length() == 0) ||
                         (d4v.getText().toString().length() == 0)
                         )
                        {

                        Toast.makeText(getApplicationContext(), " Please fill all values !", Toast.LENGTH_SHORT).show();

                        }
                     else
                        {

                        Toast.makeText(getApplicationContext(), "Generating ... Pls wait", Toast.LENGTH_LONG).show();

                        width = Integer.parseInt(widthv.getText().toString());
                        height = Integer.parseInt(heightv.getText().toString());
                        f1 = Double.parseDouble(f1v.getText().toString());
                        f2 = Double.parseDouble(f2v.getText().toString());
                        f3 = Double.parseDouble(f3v.getText().toString());
                        f4 = Double.parseDouble(f4v.getText().toString());
                        p1 = Double.parseDouble(p1v.getText().toString());
                        p2 = Double.parseDouble(p2v.getText().toString());
                        p3 = Double.parseDouble(p3v.getText().toString());
                        p4 = Double.parseDouble(p4v.getText().toString());
                        d1 = Double.parseDouble(d1v.getText().toString());
                        d2 = Double.parseDouble(d2v.getText().toString());
                        d3 = Double.parseDouble(d3v.getText().toString());
                        d4 = Double.parseDouble(d4v.getText().toString());

                        if ((width == 0) || (height == 0))
                           {
                           Toast.makeText(getApplicationContext(), "No dimension should be 0", Toast.LENGTH_SHORT).show();
                           }
                        else
                           { 

                           if ((width > 4096) || (height > 4096))
                              {

                              Toast.makeText(getApplicationContext(), "Cannot operate above image dimensions 4096 x 4096", Toast.LENGTH_LONG).show();

                              }
                           else
                              {

                              if ((width > 600) || (height > 600))
                                 {
                                 Toast.makeText(getApplicationContext(), "Images of large dimensions take some time to generate", Toast.LENGTH_LONG).show();
                                 }

                              bm = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                              generator.generate(bm,
                                                 width, height,
                                                 f1, f2,
                                                 f3, f4,
                                                 d1, d2,
                                                 d3, d4,
                                                 p1, p2,
                                                 p3, p4
                                                 );
                              iv.setImageBitmap(bm);
                              iv.setScaleType(ImageView.ScaleType.CENTER);
                              iv.setVisibility(View.VISIBLE);
                              cancel.setVisibility(View.VISIBLE);
                              save.setVisibility(View.VISIBLE);
                              generate.setVisibility(View.GONE);
                              info.setVisibility(View.GONE);

                              row1.setVisibility(View.GONE);
                              row2.setVisibility(View.GONE);
                              row3.setVisibility(View.GONE);
                              row4.setVisibility(View.GONE);
                              row5.setVisibility(View.GONE);
                              row6.setVisibility(View.GONE);
                              row7.setVisibility(View.GONE);

                              }

                           }
                        }
                     }
               });

         save.setOnClickListener(new View.OnClickListener(){

                  @Override
                  public void onClick(View v)
                     {
             
                     
                     Toast.makeText(getApplicationContext(), "Saving...", Toast.LENGTH_SHORT).show();
                     String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
                     String filename = timeStamp + ".png";
                     String root = Environment.getExternalStorageDirectory().toString();
                     File myDir = new File(root + "/Harmonographs_Simply");
                     File file = new File(myDir, filename);
                     if (!myDir.exists())
                     {
                        myDir.mkdirs();
                        }
                        if (file.exists())
                     {
                        file.delete();
                        }

                     try
                     {
                        FileOutputStream out = new FileOutputStream(file);

                        bm.compress(Bitmap.CompressFormat.PNG, 100, out);

                        out.flush();
                        out.close();                      

                        Toast.makeText(getApplicationContext(), "Image Saved", Toast.LENGTH_LONG).show();

                        cancel.setVisibility(View.GONE);
                        save.setVisibility(View.GONE);
                        iv.setVisibility(View.GONE);
                        generate.setVisibility(View.VISIBLE);
                        info.setVisibility(View.VISIBLE);

                        row1.setVisibility(View.VISIBLE);
                        row2.setVisibility(View.VISIBLE);
                        row3.setVisibility(View.VISIBLE);
                        row4.setVisibility(View.VISIBLE);
                        row5.setVisibility(View.VISIBLE);
                        row6.setVisibility(View.VISIBLE);
                        row7.setVisibility(View.VISIBLE);

                        }
                        catch (Exception e)
                     {

                        cancel.setVisibility(View.GONE);
                        save.setVisibility(View.GONE);
                        iv.setVisibility(View.GONE);
                        generate.setVisibility(View.VISIBLE);
                        info.setVisibility(View.VISIBLE);

                        row1.setVisibility(View.VISIBLE);
                        row2.setVisibility(View.VISIBLE);
                        row3.setVisibility(View.VISIBLE);
                        row4.setVisibility(View.VISIBLE);
                        row5.setVisibility(View.VISIBLE);
                        row6.setVisibility(View.VISIBLE);
                        row7.setVisibility(View.VISIBLE);

                        Toast.makeText(getApplicationContext(), "Couldn't Save Image", Toast.LENGTH_SHORT).show();

                        }
                        }
                     });

         cancel.setOnClickListener(new View.OnClickListener(){

                  @Override
                  public void onClick(View v)
                  {

                     iv.setVisibility(View.GONE);
                     save.setVisibility(View.GONE);
                     cancel.setVisibility(View.GONE);
                     generate.setVisibility(View.VISIBLE);
                     info.setVisibility(View.VISIBLE);
                     row1.setVisibility(View.VISIBLE);
                     row2.setVisibility(View.VISIBLE);
                     row3.setVisibility(View.VISIBLE);
                     row4.setVisibility(View.VISIBLE);
                     row5.setVisibility(View.VISIBLE);
                     row6.setVisibility(View.VISIBLE);
                     row7.setVisibility(View.VISIBLE);

                     }
                     });

         }
         }
